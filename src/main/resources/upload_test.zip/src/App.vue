<script setup>
import { ref, reactive } from "vue";
import axios from "axios";

const percent = ref({})

const upload = (file) => {
  console.log(file.file);
  upload_chunk(file.file, 0)
}

const upload_chunk = (file, index, id) => {
  const file_name = file.name;
  const file_size = file.size;
  const chunk_size = 1024 * 1024 * 5
  let chunk_num = Math.ceil(file_size / chunk_size)
  let start_dit = index * chunk_size;
  let end_dit = Math.min(start_dit + chunk_size, file_size)
  console.log(start_dit + chunk_size);
  console.log(file_size);
  console.log('-=====', start_dit, end_dit);
  const chunk = file.slice(start_dit, end_dit)
  if (index == 0) {
    percent.value[file_name] = {
      percent: (((index + 1) / chunk_num) * 100).toFixed(0),
      canceled: false
    }
  } else {
    percent.value[file_name] = {
      percent: (((index + 1) / chunk_num) * 100).toFixed(0),
      canceled: percent.value[file_name].canceled
    }
  }
  if (percent.value[file_name].canceled == true) {
    Reflect.deleteProperty(percent.value, file_name)
    return
  }
  // 上传
  let data = new FormData()
  data.append("file", chunk)
  data.append("file_name", file_name)
  data.append("chunk_num", chunk_num)
  data.append("chunk_index", index)
  data.append("file_id", id)
  data.append("file_size", file_size)
  axios.post(`http://127.0.0.1:8080/stream/upload?chunkNum=${chunk_num}&chunkIndex=${index}`, data, {
    headers: {
      Authorization: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOiIxODExNzUzNTI4ODAwNDg5NDcyIiwicm5TdHIiOiJaaG5QVWZpcExZbU9GUEtUVTg4S1AxU25kSEd4VXNLdSJ9.TQ-2bh3LYWnwLe8TkH8gIFg8crr0RYR49WjDxG0y5l8'
    }
  }).then(res => {
    if (chunk_num == index + 1) {
      Reflect.deleteProperty(percent.value, file_name)
      return
    } else {
      upload_chunk(file, index + 1, res.data.data)
    }
  })

}

const cancel_task = (file_name) => {
  percent.value[file_name].canceled = true
  Reflect.deleteProperty(percent.value, file_name)
  console.log(percent.value[file_name]);
}
</script>

<template>
  <el-upload :show-file-list="false" multiple :on-preview="handlePreview" :on-remove="handleRemove"
    :before-remove="beforeRemove" :http-request="upload" :on-exceed="handleExceed">
    <el-button type="primary">Click to upload</el-button>
    <template #tip>
      <div class="el-upload__tip">
        jpg/png files with a size less than 500KB.
      </div>
    </template>
  </el-upload>
  <span v-for="(index, item) in percent">
    <el-tag>文件名:{{ item }}</el-tag>
    <el-progress :percentage="index.percent" />
    <el-button @click="cancel_task(item)">取消上传</el-button>
  </span>
  <el-button @click="percent = {}">清空任务</el-button>
</template>

<style scoped></style>
